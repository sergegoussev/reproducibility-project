#' A real data set on sold milk
#'
#' A collection of scanner data on the sale of milk in one of Polish supermarkets in the period from December 2018 to August 2020
#' @format A data frame with 6 columns and 4386 rows. The used variables are as follows:
#'
#' \code{time} - Dates of transactions (Year-Month-Day)
#'
#' \code{prices} - Prices of sold products [PLN]
#'
#' \code{quantities} - Quantities of sold products [liters]
#'
#' \code{prodID} - Unique product codes (data set contains 68 different prodIDs)
#'
#' \code{retID} - Unique codes identifying outlets/retailer sale points (data set contains 5 different retIDs)
#'
#' \code{description} Descriptions of sold milk products (data set contains 6 different product descriptions)
#' @docType data
#'
"milk"