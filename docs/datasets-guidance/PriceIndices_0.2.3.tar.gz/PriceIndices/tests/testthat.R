library(testthat)
library(PriceIndices)

test_check("PriceIndices")
